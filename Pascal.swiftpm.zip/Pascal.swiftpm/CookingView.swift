//
//  CookingView.swift
//  Pascal
//
//  Created by Paarth Singh on 16/02/26.
//

import SwiftUI
import AVFoundation

struct CookingView: View {
    let totalTime: Int
    let targetDoneness: Doneness

    @State private var timeElapsed: Double = 0
    @State private var timerActive = true
    @State private var startTime: Date?
    
    @State private var timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.scenePhase) var scenePhase

    private var progress: Double {
        guard totalTime > 0 else { return 1 }
        return min(timeElapsed / Double(totalTime), 1.0)
    }

    private var isDone: Bool { timeElapsed >= Double(totalTime) }
    
    private var dynamicYolkColor: Color {
        let rawColor = Color.orange
        let jammyColor = Color.yellow
        let solidColor = Color(red: 0.96, green: 0.86, blue: 0.45)
        
        switch targetDoneness {
        case .soft:
            return Color.mix(from: rawColor, to: jammyColor, progress: progress * 0.3)
        case .medium:
            return Color.mix(from: rawColor, to: jammyColor, progress: progress)
        case .hard:
            if progress < 0.5 {
                return Color.mix(from: rawColor, to: jammyColor, progress: progress * 2)
            } else {
                return Color.mix(from: jammyColor, to: solidColor, progress: (progress - 0.5) * 2)
            }
        }
    }
    
    private var yolkSolidifyScale: Double {
        switch targetDoneness {
        case .soft: return 1.0
        case .medium: return 1.0 - (progress * 0.1)
        case .hard: return 1.0 - (progress * 0.2)
        }
    }

    private var specularOpacity: Double {
        switch targetDoneness {
        case .soft: return 0.5 // Stays wet and shiny
        case .medium: return max(0.1, 0.5 - (progress * 0.4))
        case .hard: return max(0.0, 0.5 - (progress * 0.6)) //matte
        }
    }

    var body: some View {
        VStack {
            HStack {
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.largeTitle)
                        .foregroundStyle(.white.opacity(0.8))
                }
                Spacer()
            }
            .padding()

            Spacer()

            ZStack {
              
                Circle()
                    .fill(.white.opacity(0.9))
                    .frame(width: 250, height: 250)
                    .shadow(color: .white.opacity(0.2), radius: 30)
                
                Circle()
                    .fill(dynamicYolkColor.gradient)
                    .frame(width: 110 * yolkSolidifyScale, height: 110 * yolkSolidifyScale)
                    .shadow(radius: 10)
                    .overlay {
                        Circle()
                            .stroke(.white.opacity(specularOpacity), lineWidth: 4)
                            .blur(radius: 4)
                            .offset(x: -20, y: -20)
                    }
                    .animation(.linear(duration: 0.1), value: progress)
            }

            Spacer()

            VStack(spacing: 20) {
                Text(isDone ? "Bon Appétit!" : "Cooking...")
                    .font(.system(.title, design: .rounded).weight(.bold))
                    .foregroundStyle(.white)
                
                Text(DataModel.formatCountdown(Double(totalTime) - timeElapsed))
                    .font(.system(size: 80, weight: .thin, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(.white)
                    .shadow(radius: 10)
 
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(.white.opacity(0.2))
                            .frame(height: 8)
                        
                        Capsule().fill(isDone ? Color.green : Color.orange)
                            .frame(width: geo.size.width * progress, height: 8)
                            .shadow(color: .orange, radius: 10)
                            .animation(.linear(duration: 0.1), value: progress)
                    }
                }
                .frame(height: 8)
                .padding(.horizontal, 40)
                
                if isDone {
                    Button("Finish") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .controlSize(.large)
                    .padding(.top)
                }
            }
            .padding(.bottom, 60)
        }
        .background {
            Image("Image")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .blur(radius: 10)
                .overlay(Color.black.opacity(0.5))
        }
        .onAppear {
            startTime = Date()
            NotificationManager.shared.scheduleNotification(seconds: totalTime)
        }
        .onDisappear {
            NotificationManager.shared.cancelNotification()
        }
        .onReceive(timer) { _ in

            if timerActive && timeElapsed >= Double(totalTime) {
                timerActive = false // Stop the timer
                
                // Play the classic iOS system timer chime directly!
                AudioServicesPlayAlertSound(SystemSoundID(1304))
                
                // Trigger a haptic vibration
                let generator = UINotificationFeedbackGenerator()
                generator.notificationOccurred(.success)
                return
            }
            
            guard timerActive, timeElapsed < Double(totalTime) else { return }
            timeElapsed += 0.1
        }
        .onChange(of: scenePhase) { newPhase in
            if newPhase == .active {
                if let start = startTime {
                    let realSecondsElapsed = Date().timeIntervalSince(start)
                    timeElapsed = min(realSecondsElapsed, Double(totalTime))
                }
            }
        }
    }
}
