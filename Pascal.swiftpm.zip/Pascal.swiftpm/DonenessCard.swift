//
//  DonenessCard.swift
//  Pascal
//
//  Created by GEU on 19/02/26.
//

import SwiftUI

struct DonenessCard: View {
    let doneness: Doneness
    @Binding var selectedDoneness: Doneness
    
    private var isSelected: Bool {
        doneness == selectedDoneness
    }
    
    var body: some View {
        Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                selectedDoneness = doneness
            }
        } label: {
            VStack(alignment: .leading, spacing: 0) {
                
                ZStack {
                    Rectangle()
                        .fill(donenessBackgroundColor.gradient)
                    
                    Circle()
                        .fill(.white)
                        .frame(width: 36, height: 36)
                        .shadow(color: .black.opacity(0.1), radius: 3, y: 2)
                        .overlay {
                            Circle()
                                .fill(yolkColor)
                                .frame(width: 16, height: 16)
                                .shadow(color: yolkColor.opacity(0.5), radius: 2, y: 1)
                        }
                }
                .frame(height: 70)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(doneness.label)
                        .font(.system(.subheadline, design: .rounded).weight(.bold))
                        .foregroundStyle(Color.primary)
                        .opacity(isSelected ? 1.0 : 0.6)
                        
                    Text(doneness.subtitle)
                        .font(.caption2)
                        .foregroundStyle(Color.primary)
                        .opacity(0.5)
                        .lineLimit(1)
                }
                .padding(12)
            }

            .background(.regularMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .shadow(color: isSelected ? .orange.opacity(0.3) : .black.opacity(0.06), radius: 10, y: 5)
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(isSelected ? Color.orange : Color.white.opacity(0.3), lineWidth: isSelected ? 2 : 1)
            )
        }
        .buttonStyle(.plain)
    }
    
    private var donenessBackgroundColor: Color {
        switch doneness {
        case .soft: return .orange.opacity(0.15)
        case .medium: return .yellow.opacity(0.15)
        case .hard: return Color.blue.opacity(0.08)
        }
    }
    
    private var yolkColor: Color {
        switch doneness {
        case .soft: return .orange
        case .medium: return .yellow
        case .hard: return Color(red: 0.95, green: 0.85, blue: 0.5)
        }
    }
}
