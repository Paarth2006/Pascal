//
//  DataModels.swift
//  Pascal
//
//  Created by Paarth Singh  on 17/02/26.
//
import Foundation

struct DataModel {

    static func calculateBoilingTime(
        size: EggSize,
        startTemp: Double,
        doneness: Doneness,
        pressureKPa: Double
    ) -> Int {
        let targetTemp = doneness.rawValue
        let M = size.rawValue
    
        let boilingPoint = 100.0 * pow((pressureKPa / 101.325), 0.24)
        
        let waterStartTemp = 20.0
        let waterRampDuration = 480.0
       
        let tau = 0.451 * pow(M, 2.0 / 3.0) * 60.0 * 0.85
        
        var currentEggTemp = startTemp
        var currentTime = 0.0
        let dt = 1.0
        while currentEggTemp < targetTemp {
            // Calculate water temperature at the current second
            let currentWaterTemp: Double
            if currentTime < waterRampDuration {
                currentWaterTemp = waterStartTemp + (boilingPoint - waterStartTemp) * (currentTime / waterRampDuration)
            } else {
                currentWaterTemp = boilingPoint
            }
            
            // Heat transfer based on Newtons Law of Cooling
            let heatTransfer = (currentWaterTemp - currentEggTemp) / tau
            currentEggTemp += heatTransfer * dt
            
            currentTime += dt
           
            if currentTime > 7200 { break }
        }
        
        return Int(currentTime)
    }

    static func calculateBoilingPoint(pressureKPa: Double) -> Double {
        return 100.0 * pow((pressureKPa / 101.325), 0.24)
    }

    static func formatEstimatedTime(_ totalSeconds: Int) -> String {
        guard totalSeconds > 0 else { return "—" }
        let min = totalSeconds / 60
        let sec = totalSeconds % 60
        if min == 0 { return "\(sec)s" }
        if sec == 0 { return "\(min) min" }
        return "\(min) min \(sec)s"
    }

    static func formatCountdown(_ totalSeconds: Double) -> String {
        let t = max(totalSeconds, 0)
        let m = Int(t) / 60
        let s = Int(t) % 60
        return String(format: "%02d:%02d", m, s)
    }
}
