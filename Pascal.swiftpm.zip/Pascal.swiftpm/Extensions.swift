//
//  Extensions.swift
//  Pascal
//
//  Created by GEU on 19/02/26.

import SwiftUI

extension Color {
    static func mix(from color1: Color, to color2: Color, progress: Double) -> Color {
        let p = min(max(progress, 0), 1)
        
        let c1 = UIColor(color1)
        let c2 = UIColor(color2)
        
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0
        var r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        
        c1.getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
        c2.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        
        let r = r1 + (r2 - r1) * CGFloat(p)
        let g = g1 + (g2 - g1) * CGFloat(p)
        let b = b1 + (b2 - b1) * CGFloat(p)
        let a = a1 + (a2 - a1) * CGFloat(p)
        
        return Color(uiColor: UIColor(red: r, green: g, blue: b, alpha: a))
    }
}


//Liquid Glass Effect

struct LiquidGlassCard: ViewModifier {
    func body(content: Content) -> some View {
        content
           
            .background(.ultraThinMaterial)
     
            .overlay(
                RoundedRectangle(cornerRadius: 25, style: .continuous)
                    .stroke(
                        LinearGradient(
                            colors: [
                                .white.opacity(0.8),
                                .white.opacity(0.1),
                                .white.opacity(0.1),
                                .white.opacity(0.4)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1.5
                    )
            )
            .clipShape(RoundedRectangle(cornerRadius: 25, style: .continuous))
            .shadow(color: .black.opacity(0.15), radius: 20, x: 0, y: 10)
    }
}

extension View {
    func glassCard() -> some View {
        modifier(LiquidGlassCard())
    }
}
