//
//  Models.swift
//  Pascal
//
//  Created by Paarth Singh  on 17/02/26.
//
import Foundation
import SwiftUI

enum EggSize: Double, CaseIterable {
    case small = 53.0
    case medium = 58.0
    case large = 63.0
    case extraLarge = 73.0

    var label: String {
        switch self {
        case .small:      return "S"
        case .medium:     return "M"
        case .large:      return "L"
        case .extraLarge: return "XL"
        }
    }

    var grams: String {
        switch self {
        case .small:      return "53g"
        case .medium:     return "58g"
        case .large:      return "63g"
        case .extraLarge: return "73g"
        }
    }

    var dotSize: CGFloat {
        switch self {
        case .small:      return 18
        case .medium:     return 24
        case .large:      return 30
        case .extraLarge: return 36
        }
    }
}

enum Doneness: Double, CaseIterable {
    case soft   = 63.0
    case medium = 70.0
    case hard   = 77.0

    var label: String {
        switch self {
        case .soft:   return "Soft"
        case .medium: return "Medium"
        case .hard:   return "Hard"
        }
    }

    var subtitle: String {
        switch self {
        case .soft:   return "Runny yolk"
        case .medium: return "Jammy yolk"
        case .hard:   return "Firm yolk"
        }
    }

    var imageName: String {
        switch self {
        case .soft:   return "soft_boiled"
        case .medium: return "medium_boiled"
        case .hard:   return "hard_boiled"
        }
    }
}

struct EggTimeline {
    let softSeconds: Int
    let mediumSeconds: Int
    let hardSeconds: Int
}
