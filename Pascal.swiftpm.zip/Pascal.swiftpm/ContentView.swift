//
//  ContentView.swift
//  Pascal
//
//  Created by Paarth Singh on 16/02/26.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var sensor = SensorManager()
    @State private var selectedSize: EggSize = .large
    @State private var selectedDoneness: Doneness = .soft
    @State private var startTempText: String = "4"
    @State private var isCooking = false
    @FocusState private var tempFocused: Bool

    private var startTemp: Double { Double(startTempText) ?? 4.0 }

    private var cookingSeconds: Int {
        DataModel.calculateBoilingTime(
            size: selectedSize,
            startTemp: startTemp,
            doneness: selectedDoneness,
            pressureKPa: sensor.pressure
        )
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {
                HStack {
                    Text("Kitchen")
                        .font(.system(.largeTitle, design: .rounded).weight(.bold))
                        .foregroundStyle(.white)
                        .shadow(color: .black.opacity(0.6), radius: 4, x: 0, y: 2)
                    Spacer()
                }
                .padding(.top, 10)
                
                sensorCard
                    .glassCard()
                
                settingsCard
                    .glassCard()
            
                estimatedTimeCard
                    .glassCard()
 
                startButton
                    .padding(.top, 4)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 120)
        }
        .background {
            Image("Image")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
        }
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") {
                    tempFocused = false
                }
                .font(.headline)
                .tint(.orange)
            }
        }
        .navigationBarHidden(true)
        .fullScreenCover(isPresented: $isCooking) {
            CookingView(totalTime: cookingSeconds, targetDoneness: selectedDoneness)
        }
        .onAppear {
            sensor.startMonitoring()
            NotificationManager.shared.requestPermission()
        }
        .preferredColorScheme(.light)
    }
    
    private var sensorCard: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Label("LIVE PRESSURE", systemImage: "barometer")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(.primary.opacity(0.7))
                
                Text("\(String(format: "%.1f", sensor.pressure)) kPa")
                    .font(.system(.title2, design: .rounded).weight(.semibold))
                    .foregroundStyle(.primary)
            }
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 4) {
                Label("BOILING POINT", systemImage: "thermometer.medium")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(.orange)
                
                Text("\(String(format: "%.1f", sensor.boilingPoint))°C")
                    .font(.system(.title2, design: .rounded).weight(.bold))
                    .foregroundStyle(.orange)
            }
        }
        .padding(20)
    }

    private var settingsCard: some View {
        VStack(alignment: .leading, spacing: 18) {
            
            VStack(alignment: .leading, spacing: 10) {
                Text("Egg Size")
                    .font(.headline)
                    .foregroundStyle(.primary)
                
                HStack(spacing: 12) {
                    ForEach(EggSize.allCases, id: \.self) { size in
                        SizeButton(size: size, selectedSize: $selectedSize)
                    }
                }
            }
            
            Divider().background(.primary.opacity(0.2))
            
            // Temperature Section
            HStack {
                VStack(alignment: .leading) {
                    Text("Egg Temp")
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Text("Starting temperature")
                        .font(.caption)
                        .foregroundStyle(.primary.opacity(0.7))
                }
                Spacer()
                HStack(spacing: 4) {
                    TextField("4", text: $startTempText)
                        .keyboardType(.decimalPad)
                        .focused($tempFocused)
                        .multilineTextAlignment(.trailing)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                        .frame(width: 50)
                    Text("°C")
                        .font(.body.weight(.medium))
                        .foregroundStyle(.primary.opacity(0.7))
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(.thinMaterial)
                .cornerRadius(12)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(.white.opacity(0.3), lineWidth: 1))
            }
            
            Divider().background(.primary.opacity(0.2))
            
            // Doneness Section
            VStack(alignment: .leading, spacing: 10) {
                Text("Desired Doneness")
                    .font(.headline)
                    .foregroundStyle(.primary)
                
                HStack(spacing: 10) {
                    ForEach(Doneness.allCases, id: \.self) { done in
                        DonenessCard(doneness: done, selectedDoneness: $selectedDoneness)
                    }
                }
            }
        }
        .padding(20)
    }

    private var estimatedTimeCard: some View {
        HStack {
            VStack(alignment: .leading) {
                Text("ESTIMATED TIME")
                    .font(.caption.weight(.bold))
                    .tracking(1)
                    .foregroundStyle(.primary.opacity(0.7))
                
                Text(DataModel.formatEstimatedTime(cookingSeconds))
                    .font(.system(size: 42, weight: .medium, design: .rounded))
                    .foregroundStyle(.primary)
                    .contentTransition(.numericText(countsDown: false))
            }
            Spacer()
            Image(systemName: "timer")
                .font(.system(size: 30))
                .foregroundStyle(.orange.opacity(0.8))
        }
        .padding(20)
        .animation(.spring, value: cookingSeconds)
    }

    private var startButton: some View {
        Button {
            tempFocused = false
            isCooking = true
        } label: {
            Text("Start Cooking")
                .font(.headline)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(Color.orange)
                .cornerRadius(25)
                .shadow(color: .orange.opacity(0.4), radius: 15, y: 5)
                .overlay(
                    RoundedRectangle(cornerRadius: 25)
                        .stroke(LinearGradient(colors: [.white.opacity(0.5), .clear], startPoint: .top, endPoint: .bottom), lineWidth: 1)
                )
        }
    }
}
