//
//  ScienceView.swift
//  Pascal
//
//  Created by Paarth Singh on 16/02/26.
//
import SwiftUI

struct ScienceView: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.99, green: 0.96, blue: 0.90), Color(red: 1.0, green: 0.99, blue: 0.96)],
                startPoint: .top, endPoint: .bottom
            )
            .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    HStack {
                        Text("Theory")
                            .font(.system(.largeTitle, design: .rounded).weight(.bold))
                            .foregroundStyle(.primary)
                        Spacer()
                    }
                    .padding(.top, 10)
                    .padding(.bottom, 8)

                    TheoryCard(
                        icon: "flask.fill",
                        iconColor: Color.orange,
                        iconBg: Color(red: 1, green: 0.9, blue: 0.75),
                        title: "Why altitude matters",
                        bodyText: "The boiling point of water changes with air pressure. At higher altitudes, lower pressure means water boils at a lower temperature — which directly affects how long it takes to cook an egg."
                    )
                    TheoryCard(
                        icon: "chart.line.uptrend.xyaxis",
                        iconColor: Color(red: 0.2, green: 0.5, blue: 0.95),
                        iconBg: Color(red: 0.87, green: 0.93, blue: 1.0),
                        title: "Pressure drops with altitude",
                        bodyText: "As you go higher, the column of air above you gets lighter. This reduces the pressure pushing down on water, allowing it to boil at a lower temperature."
                    )
                    TheoryCard(
                        icon: "thermometer.medium",
                        iconColor: Color(red: 0.95, green: 0.4, blue: 0.2),
                        iconBg: Color(red: 1.0, green: 0.88, blue: 0.82),
                        title: "Dehradun Example",
                        bodyText: "At ~450m above sea level, pressure is around 95 kPa. Water boils at ~98°C instead of the standard 100°C at sea level — a 2°C difference that adds real cooking time."
                    )
                    TheoryCard(
                        icon: "timer",
                        iconColor: Color(red: 0.1, green: 0.72, blue: 0.45),
                        iconBg: Color(red: 0.82, green: 0.96, blue: 0.88),
                        title: "Pascal adjusts automatically",
                        bodyText: "Pascal reads your barometer in real time, calculates the local boiling point, and applies a heat-transfer formula to find the exact time for your chosen doneness."
                    )

                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "lightbulb.fill")
                            .font(.system(size: 18))
                            .foregroundColor(Color(red: 0.9, green: 0.7, blue: 0.0))
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Pro Tip")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundColor(.black.opacity(0.85))
                            Text("Eggs that are 3–5 days old peel far more easily than fresh eggs after boiling.")
                                .font(.system(size: 13))
                                .foregroundColor(.black.opacity(0.65))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(red: 1.0, green: 0.97, blue: 0.82))
                    .cornerRadius(16)
                }
                .padding(.horizontal, 18)
                .padding(.top, 8)
                .padding(.bottom, 100)
            }
        }
        .navigationBarHidden(true)
        .preferredColorScheme(.light)
    }
}

struct TheoryCard: View {
    let icon: String
    let iconColor: Color
    let iconBg: Color
    let title: String
    let bodyText: String

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                Circle()
                    .fill(iconBg)
                    .frame(width: 46, height: 46)
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundColor(iconColor)
            }
            .padding(.top, 2)

            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.black.opacity(0.85))
                Text(bodyText)
                    .font(.system(size: 13))
                    .foregroundColor(.black.opacity(0.65))
                    .fixedSize(horizontal: false, vertical: true)
                    .lineSpacing(3)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.04), radius: 8, x: 0, y: 3)
    }
}
