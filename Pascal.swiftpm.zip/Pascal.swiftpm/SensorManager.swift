//
//  SensorManager.swift
//  Pascal
//
//  Created by Paarth Singh  on 16/02/26.
//
import Foundation
import CoreMotion

@MainActor
class SensorManager: ObservableObject {
    @Published var pressure: Double = 101.325
    @Published var boilingPoint: Double = 100.0
    @Published var isSensorActive: Bool = false

    private let altimeter = CMAltimeter()

    func startMonitoring() {
        guard CMAltimeter.isRelativeAltitudeAvailable() else { return }
        isSensorActive = true
        altimeter.startRelativeAltitudeUpdates(to: .main) { [weak self] data, error in
            guard let self, let data, error == nil else { return }
            let kPa = data.pressure.doubleValue
            self.pressure = kPa
            self.boilingPoint = DataModel.calculateBoilingPoint(pressureKPa: kPa)
        }
    }

    func stopMonitoring() {
        altimeter.stopRelativeAltitudeUpdates()
        isSensorActive = false
    }
}
