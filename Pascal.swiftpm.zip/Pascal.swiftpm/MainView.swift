//
//  MainView.swift
//  Pascal
//
//  Created by Paarth Singh  on 16/02/26.
//
import SwiftUI

struct MainView: View {
    var body: some View {
        TabView {
            NavigationView {
                ContentView()
            }
            .navigationViewStyle(.stack)
            .tabItem {
                Label("Kitchen", systemImage: "flame.fill")
            }

            NavigationView {
                ScienceView()
            }
            .navigationViewStyle(.stack)
            .tabItem {
                Label("Theory", systemImage: "brain.head.profile")
            }
        }
        .accentColor(.orange)
    }
}
