//
//  SizeButton.swift
//  Pascal
//
//  Created by GEU on 19/02/26.
//

import SwiftUI

struct SizeButton: View {
    let size: EggSize
    @Binding var selectedSize: EggSize

    private var isSelected: Bool {
        size == selectedSize
    }

    var body: some View {
        Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                selectedSize = size
            }
        } label: {
            VStack(spacing: 8) {
                Circle()
                    .fill(isSelected ? Color.orange : Color.secondary.opacity(0.2))
                    .frame(width: size.dotSize, height: size.dotSize)
               
                VStack(spacing: 2) {
                    Text(size.label)
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .foregroundStyle(isSelected ? .primary : .secondary)
                    
                    Text(size.grams)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(isSelected ? Color.orange.opacity(0.1) : Color.clear)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(isSelected ? Color.orange : Color.secondary.opacity(0.2), lineWidth: isSelected ? 2 : 1)
            )
            .scaleEffect(isSelected ? 1.0 : 0.98)
        }
        .buttonStyle(.plain)
    }
}
