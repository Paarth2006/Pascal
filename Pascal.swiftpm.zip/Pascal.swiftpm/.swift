//
//  ThermalSimulator.swift
//  Pascal
//
//  Created by Paarth Singh  on 17/02/26.
//
import Foundation
import SwiftUI

class ThermalSimulator: ObservableObject {
    // INPUTS
    @Published var initialTemp: WaterTemp = .normal
    @Published var flameStrength: FlameStrength = .medium
    
    // OUTPUTS
    @Published var currentSimulatedTemp: Double = 25.0
    @Published var progress: Double = 0.0
    
    // NEW: The "Head Start" Logic
    @Published var effectiveCookedSeconds: Double = 0.0 // Time already "cooked"
    
    // CONSTANTS
    let volumeMass: Double = 1500.0
    let specificHeat: Double = 4.186
    let efficiency: Double = 0.45
    
    // CONSTANTS FOR COOKING PHYSICS
    let cookingThreshold: Double = 60.0 // Proteins start setting here
    
    func reset() {
        currentSimulatedTemp = initialTemp.value
        progress = 0.0
        effectiveCookedSeconds = 0.0
    }
    
    // RUNS EVERY SECOND
    func updateSimulation(targetBoilingPoint: Double) -> Bool {
        // 1. Heat the Water (Same as before)
        let energyInput = flameStrength.power * 1.0 * efficiency
        let tempRise = energyInput / (volumeMass * specificHeat)
        currentSimulatedTemp += tempRise
        
        // 2. NEW: Calculate "Effective Cooking" if water is hot enough
        if currentSimulatedTemp > cookingThreshold {
            // How efficient is the cooking at this temp?
            // At 60°C = 0% speed. At 100°C = 100% speed.
            let cookingEfficiency = (currentSimulatedTemp - cookingThreshold) / (targetBoilingPoint - cookingThreshold)
            
            // Add to our "Bank" of cooked time
            // e.g., if efficiency is 0.5, 1 real second = 0.5 cooked seconds
            effectiveCookedSeconds += max(0, cookingEfficiency)
        }
        
        // 3. Update Visual Progress
        let totalRange = targetBoilingPoint - initialTemp.value
        let currentRise = currentSimulatedTemp - initialTemp.value
        progress = min(currentRise / totalRange, 1.0)
        
        return currentSimulatedTemp >= targetBoilingPoint
    }
}
